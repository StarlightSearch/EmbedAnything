import embed_anything
from embed_anything import EmbedData


data = embed_anything.embed_file("TUe_SOP_AI_2.pdf")

print(data[0])